-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 05, 2013 at 05:46 AM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dbtera`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE IF NOT EXISTS `accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `firstname` varchar(25) DEFAULT NULL,
  `lastname` varchar(50) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `displayname` varchar(25) DEFAULT NULL,
  `regdate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `lastdate` timestamp NULL DEFAULT NULL,
  `lastip` varchar(15) DEFAULT NULL,
  `coins` int(11) NOT NULL DEFAULT '0',
  `role` int(11) NOT NULL DEFAULT '1',
  `country` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `ban` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `servers`
--

CREATE TABLE IF NOT EXISTS `servers` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `small_text` text NOT NULL,
  `img` longtext NOT NULL,
  `ip` varchar(22) NOT NULL,
  `port` int(5) NOT NULL,
  `category` varchar(3) NOT NULL,
  `name` varchar(25) NOT NULL,
  `crowdness` text NOT NULL,
  `open` int(11) NOT NULL,
  `permission_mask` varchar(15) NOT NULL DEFAULT '0x00000000',
  `server_stat` varchar(15) NOT NULL DEFAULT '0x00000001',
  `language` varchar(2) NOT NULL DEFAULT 'en',
  `l_visible` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `servers`
--

INSERT INTO `servers` (`id`, `title`, `small_text`, `img`, `ip`, `port`, `category`, `name`, `crowdness`, `open`, `permission_mask`, `server_stat`, `language`, `l_visible`) VALUES
(1, 'Tera Chaos', 'terachaos', '', '10.0.0.4', 11101, 'PvE', 'terachaos', 'Average', 1, '0x00000000', '0x00000001', 'en', 0),
(2, 'Tera Intranet', 'teraintranet', '', '10.0.0.4', 11101, 'PvE', 'teraintranet', 'Average', 1, '0x00000000', '0x00000001', 'en', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
